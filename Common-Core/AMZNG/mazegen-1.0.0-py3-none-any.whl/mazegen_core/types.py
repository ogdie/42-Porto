Coordinate = tuple[int, int]
